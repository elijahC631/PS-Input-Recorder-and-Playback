import pygame
from input_state import InputState

pygame.init()
pygame.joystick.init()

js = pygame.joystick.Joystick(0)
js.init()

state = InputState(js)

print("Testing InputState (Ctrl+C to stop)")
while True:
    state.update()
    snap = state.snapshot()

    if any(snap["buttons"].values()) or any(abs(v) > 0 for v in snap["axes"].values()):
        print(snap)