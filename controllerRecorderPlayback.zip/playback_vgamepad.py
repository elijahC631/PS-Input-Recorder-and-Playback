import json
import time
import vgamepad as vg

def stick_float_to_int(value):
    value = max(-1.0, min(1.0, value))
    return int(value * 32767)

def trigger_float_to_int(value):
    value = max(0.0, min(1.0, value))
    return int(value * 255)


# ----------------------------
# Load recording
# ----------------------------
with open("recording.json", "r") as f:
    frames = json.load(f)

print(f"Loaded {len(frames)} frames")

# ----------------------------
# Create virtual controller
# ----------------------------
gamepad = vg.VDS4Gamepad()

# ----------------------------
# Button mapping
# ----------------------------
BUTTON_MAP = {
    "X": vg.DS4_BUTTONS.DS4_BUTTON_CROSS,
    "CIRCLE": vg.DS4_BUTTONS.DS4_BUTTON_CIRCLE,
    "SQUARE": vg.DS4_BUTTONS.DS4_BUTTON_SQUARE,
    "TRIANGLE": vg.DS4_BUTTONS.DS4_BUTTON_TRIANGLE,

    "L1": vg.DS4_BUTTONS.DS4_BUTTON_SHOULDER_LEFT,
    "R1": vg.DS4_BUTTONS.DS4_BUTTON_SHOULDER_RIGHT,

    "OPTIONS": vg.DS4_BUTTONS.DS4_BUTTON_OPTIONS,
    "SHARE": vg.DS4_BUTTONS.DS4_BUTTON_SHARE,

    "L3": vg.DS4_BUTTONS.DS4_BUTTON_THUMB_LEFT,
    "R3": vg.DS4_BUTTONS.DS4_BUTTON_THUMB_RIGHT,
}

# ----------------------------
# Playback loop
# ----------------------------
start_time = time.perf_counter()
last_buttons = {}

for frame in frames:
    # Timing sync
    now = time.perf_counter()
    wait = frame["t"] - (now - start_time)
    if wait > 0:
        time.sleep(wait)

    buttons = frame["buttons"]
    axes = frame["axes"]

    # ---- Buttons ----
    for name, pressed in buttons.items():
        if name not in BUTTON_MAP:
            continue

        if pressed and not last_buttons.get(name, False):
            gamepad.press_button(BUTTON_MAP[name])
        elif not pressed and last_buttons.get(name, False):
            gamepad.release_button(BUTTON_MAP[name])

        last_buttons[name] = pressed

    # ---- Sticks (float → int) ----
    gamepad.left_joystick(
        stick_float_to_int(axes.get("LX", 0.0)),
        stick_float_to_int(axes.get("LY", 0.0))
    )

    gamepad.right_joystick(
        stick_float_to_int(axes.get("RX", 0.0)),
        stick_float_to_int(axes.get("RY", 0.0))
    )

    # ---- Triggers (float → int) ----
    gamepad.left_trigger(
        trigger_float_to_int(axes.get("L2", 0.0))
    )

    gamepad.right_trigger(
        trigger_float_to_int(axes.get("R2", 0.0))
    )

    # Apply frame
    gamepad.update()

print("Playback finished")