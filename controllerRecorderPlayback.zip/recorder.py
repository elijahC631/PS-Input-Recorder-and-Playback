import time
import json


class InputRecorder:
    def __init__(self):
        self.start_time = None
        self.frames = []

    def start(self):
        self.start_time = time.perf_counter()
        self.frames = []

    def record(self, snapshot):
        if self.start_time is None:
            return

        timestamp = time.perf_counter() - self.start_time
        self.frames.append({
            "t": round(timestamp, 6),
            "buttons": snapshot["buttons"],
            "axes": snapshot["axes"]
        })

    def save(self, filename="recording.json"):
        with open(filename, "w") as f:
            json.dump(self.frames, f, indent=2)

        print(f"Saved {len(self.frames)} frames to {filename}")