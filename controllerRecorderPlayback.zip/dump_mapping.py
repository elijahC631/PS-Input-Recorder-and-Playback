import pygame

pygame.init()
pygame.joystick.init()

js = pygame.joystick.Joystick(0)
js.init()

print("Controller Name:", js.get_name())
print("Buttons:", js.get_numbuttons())
print("Axes:", js.get_numaxes())
print("Hats:", js.get_numhats())
print()

print("=== AXIS TEST ===")
print("Move sticks and triggers (Ctrl+C to stop)")
while True:
    pygame.event.pump()
    for i in range(js.get_numaxes()):
        val = round(js.get_axis(i), 2)
        if abs(val) > 0.2:
            print(f"Axis {i}: {val}")