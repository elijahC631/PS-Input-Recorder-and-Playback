import json
import time

# Load the recording
with open("recording.json", "r") as f:
    frames = json.load(f)

print(f"Loaded {len(frames)} frames")

start_time = time.perf_counter()

for i, frame in enumerate(frames):
    # Wait until the correct timestamp
    now = time.perf_counter()
    wait_time = frame["t"] - (now - start_time)
    if wait_time > 0:
        time.sleep(wait_time)

    # Simulate applying the frame (for now just print)
    print(f"Frame {i}: Buttons {frame['buttons']}, Axes {frame['axes']}")