import pygame

DEADZONE = 0.15

BUTTON_MAP = {
    "X": 0,
    "CIRCLE": 1,
    "SQUARE": 2,
    "TRIANGLE": 3,

    "SHARE": 4,
    "PS": 5,
    "OPTIONS": 6,

    "L3": 7,
    "R3": 8,

    "L1": 9,
    "R1": 10,

    "DPAD_UP": 11,
    "DPAD_DOWN": 12,
    "DPAD_LEFT": 13,
    "DPAD_RIGHT": 14,

    "TOUCHPAD": 15,
    "MUTE": 16,
}

AXIS_MAP = {
    "LX": 0,
    "LY": 1,
    "RX": 2,
    "RY": 3,
    "L2": 4,
    "R2": 5,
}

def apply_deadzone(value, dz=DEADZONE):
    return 0.0 if abs(value) < dz else round(value, 3)


class InputState:
    def __init__(self, joystick):
        self.js = joystick
        self.buttons = {}
        self.axes = {}

    def update(self):
        pygame.event.pump()

        # Buttons
        for name, idx in BUTTON_MAP.items():
            self.buttons[name] = bool(self.js.get_button(idx))

        # Axes
        for name, idx in AXIS_MAP.items():
            val = self.js.get_axis(idx)

            # invert Y axes
            if name in ("LY", "RY"):
                val *= -1

            self.axes[name] = apply_deadzone(val)

    def snapshot(self):
        return {
            "buttons": self.buttons.copy(),
            "axes": self.axes.copy()
        }