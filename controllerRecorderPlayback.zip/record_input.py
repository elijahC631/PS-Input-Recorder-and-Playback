import pygame
import time
import os
from input_state import InputState
from recorder import InputRecorder

pygame.init()
pygame.joystick.init()



try:
    js = pygame.joystick.Joystick(0)
    js.init()


state = InputState(js)
recorder = InputRecorder()

project_dir = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(project_dir, "recording.json")

print("Press X to start recording")
print("Press O to stop and save")
print("Ctrl+C to quit")

recording = False

while True:
    state.update()
    snap = state.snapshot()

    if snap["buttons"]["X"] and not recording:
        print("Recording started")
        recorder.start()
        recording = True
        time.sleep(0.25)  # debounce

    if snap["buttons"]["CIRCLE"] and recording:
        recorder.save(filename)
        recording = False
        time.sleep(0.25)

    if recording:
        recorder.record(snap)

    time.sleep(0.008)  # ~120Hz capture