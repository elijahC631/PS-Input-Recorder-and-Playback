import time
import vgamepad as vg

gamepad = vg.VDS4Gamepad()

print("Pressing X in 2 seconds...")
time.sleep(2)

# Press X
gamepad.press_button(vg.DS4_BUTTONS.DS4_BUTTON_CROSS)
gamepad.update()
time.sleep(0.5)

# Release X
gamepad.release_button(vg.DS4_BUTTONS.DS4_BUTTON_CROSS)
gamepad.update()

print("Test finished")