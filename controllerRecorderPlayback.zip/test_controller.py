import pygame
import time

pygame.init()
pygame.joystick.init()

controller = pygame.joystick.Joystick(0)
controller.init()

prev_buttons = []
prev_axes = []

print("Controller successfully connected:", controller.get_name())
print("Move sticks or press buttons. Ctrl+C to stop.")

while True:
    pygame.event.pump()

    buttons = [controller.get_button(i) for i in range(controller.get_numbuttons())]
    axes = [round(controller.get_axis(i), 2) for i in range(controller.get_numaxes())]

    if buttons != prev_buttons or axes != prev_axes:
        print("Buttons:", buttons)
        print("Axes:", axes)
        print("-" * 40)

        prev_buttons = buttons
        prev_axes = axes

    time.sleep(0.01)